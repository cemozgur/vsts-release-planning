import * as React from 'react';
import * as ReactDOM from 'react-dom';

import {
  Instance as WorkItemSearch,
  IWorkItemSearchResult,
  IWiqlQueryResult
} from "./Feature";


interface IWorkItemSearchProps {
}

interface IWorkItemSearchState {
  result?: IWorkItemSearchResult;
}

class WorkItemSearchComponent extends React.Component<IWorkItemSearchProps, IWorkItemSearchState> {
  constructor(props?: IWorkItemSearchProps) {
    super(props);
    this.state = this._getDefaultState();

    this._performSearch();
  }
  public render(): JSX.Element {
    return <div className="work-item-search">
                Hola {this.state.result}
            </div>;
  }

  private _getDefaultState(): IWorkItemSearchState {
    return {
      result: {}
    };
  }

  private _performSearch(): void {
    WorkItemSearch.getAllFeatureByProjectResult().then(
      (result: IWorkItemSearchResult) => {
        console.log(result);
        let status = {result: result};
        this.setState(status);
    });
  }

}

export function init(containerId: string): void {
  ReactDOM.render(<WorkItemSearchComponent />, document.getElementById(containerId));
}
