var debug = process.env.NODE_ENV !== "production";
var webpack = require('webpack');
var path = require('path');

module.exports = {
  entry: "/src/components/FeatureComponent.tsx",
  output: {
    filename: "bundle.js",
    libraryTarget: "amd",
    path: __dirname + "/dist"
  },

  devtool: debug ? "source-map" : null,

  resolve: {
    extensions: [".ts", ".tsx", ".js", "jsx"]
  },

  module: {
    loaders: [{test: /\.tsx?$/, loader: "awesome-typescript-loader"}],
    preLoaders: [{ test: /\.js$/, loader: "source-map-loader"}]
  },

  externals: [{
    "q": true,
    "react": "React",
    "react-dom": "ReactDOM"
  },
  /^TFS\//, // Ignore TFS/* since they are coming from VSTS host
  /^VSS\//  // Ignore VSS/* since they are coming from VSTS host
  ]


};
