let TYPES = {
    IReleasePlan: Symbol("IReleasePlan"),
    IAlgorithm: Symbol("IAlgorithm")
};

export default TYPES;
