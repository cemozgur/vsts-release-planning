"use strict";
var TYPES = {
    IReleasePlan: Symbol("IReleasePlan"),
    IAlgorithm: Symbol("IAlgorithm")
};
exports.__esModule = true;
exports["default"] = TYPES;
