"use strict";
var GAReleasePlan = (function () {
    function GAReleasePlan() {
    }
    GAReleasePlan.prototype.getReleasePlanType = function () {
        return "GA Release Plan";
    };
    return GAReleasePlan;
}());
exports.GAReleasePlan = GAReleasePlan;
