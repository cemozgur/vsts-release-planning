"use strict";
var IFMReleasePlan = (function () {
    function IFMReleasePlan() {
    }
    IFMReleasePlan.prototype.getReleasePlanType = function () {
        return "IFM Release Plan";
    };
    return IFMReleasePlan;
}());
exports.IFMReleasePlan = IFMReleasePlan;
