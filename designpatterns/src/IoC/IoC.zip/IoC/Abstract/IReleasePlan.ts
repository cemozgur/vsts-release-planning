interface IReleasePlan{
  getReleasePlanType() : string;
}

export {IReleasePlan};
