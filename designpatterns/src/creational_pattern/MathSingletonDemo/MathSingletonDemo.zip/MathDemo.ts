import {MathFunction} from "./Math"

console.log(MathFunction.MonteCarloSimulation(10000,0.3));
