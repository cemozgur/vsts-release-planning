class MathFunction{
    private static instance: MathFunction;

    constructor(){}

    public static Mean (sum : number, number : number){
      return sum/number;
    }

    public static MonteCarloSimulation (SimulationSize: number, Probability: number){
      return 'To Be Implemented';
    }

}

export {MathFunction};
